import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

export function CTA() {
  return (
    <section className="py-32 px-6 relative overflow-hidden">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 left-10 w-32 h-32 rounded-full" style={{ background: 'var(--accent-pink)' }} />
        <div className="absolute bottom-20 right-20 w-40 h-40 rotate-45" style={{ background: 'var(--accent-yellow)' }} />
        <div className="absolute top-1/2 left-1/4 w-24 h-24 rounded-full" style={{ background: 'var(--accent-mint)' }} />
      </div>

      <div className="max-w-4xl mx-auto text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="p-12 rounded-3xl border-2 border-black dark:border-white bg-white dark:bg-[#262626]"
          style={{
            boxShadow: '12px 12px 0px 0px rgba(139, 92, 246, 1)',
          }}
        >
          <h2 className="text-5xl font-bold mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
            Ready to fix your bits?
          </h2>
          <p className="text-xl opacity-70 mb-10 max-w-2xl mx-auto">
            Join thousands of testers and startups building better products together.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <motion.button
              className="px-8 py-4 rounded-full border-2 border-black dark:border-white shadow-[6px_6px_0px_0px_rgba(236,72,153,1)] flex items-center gap-2"
              style={{ background: 'var(--accent-pink)', color: 'white', fontSize: '1.125rem', fontWeight: 600 }}
              whileHover={{ scale: 1.05, rotate: -2 }}
              whileTap={{ scale: 0.95 }}
            >
              Start Testing
              <ArrowRight className="w-5 h-5" />
            </motion.button>

            <motion.button
              className="px-8 py-4 rounded-full border-2 border-black dark:border-white shadow-[6px_6px_0px_0px_rgba(139,92,246,1)]"
              style={{ background: 'var(--primary)', color: 'white', fontSize: '1.125rem', fontWeight: 600 }}
              whileHover={{ scale: 1.05, rotate: 2 }}
              whileTap={{ scale: 0.95 }}
            >
              Launch Your Product
              <ArrowRight className="w-5 h-5 inline ml-2" />
            </motion.button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
