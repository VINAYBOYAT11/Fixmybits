import { Users, Zap } from 'lucide-react';

const logos = ['Acme', 'TechCo', 'StartupX', 'InnovateLab', 'BuilderHQ', 'Vertex', 'NexGen', 'CloudWave'];

export function TrustBar() {
  return (
    <section className="border-y-2 border-black dark:border-white bg-white dark:bg-[#262626] overflow-hidden">
      <div className="py-8 px-6 border-b-2 border-black dark:border-white">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-full border-2 border-black dark:border-white" style={{ background: 'var(--accent-mint)' }}>
              <Users className="w-6 h-6 text-black" />
            </div>
            <div>
              <div className="text-3xl font-bold" style={{ fontFamily: 'var(--font-heading)' }}>
                25,000+
              </div>
              <div className="text-sm opacity-60">Active Researchers</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-3 rounded-full border-2 border-black dark:border-white" style={{ background: 'var(--accent-yellow)' }}>
              <Zap className="w-6 h-6 text-black" />
            </div>
            <div className="text-xl font-medium">Effortless integrations</div>
          </div>
        </div>
      </div>

      <div className="relative py-6">
        <div className="flex animate-marquee whitespace-nowrap">
          {[...logos, ...logos, ...logos].map((logo, index) => (
            <div
              key={index}
              className="mx-8 text-2xl font-bold opacity-40"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              {logo}
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes marquee {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-33.333%);
          }
        }
        .animate-marquee {
          animation: marquee 25s linear infinite;
        }
        .animate-marquee:hover {
          animation-play-state: paused;
        }
      `}</style>
    </section>
  );
}
