import { motion } from 'motion/react';
import { ThemeToggle } from './ThemeToggle';
import logo from '../../imports/ChatGPT_Image_Apr_18,_2026,_08_22_47_PM.png';

export function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b-2 border-black dark:border-white">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="cursor-pointer"
        >
          <img src={logo} alt="FixMyBits" className="h-10 dark:invert" />
        </motion.div>

        <div className="hidden md:flex items-center gap-8">
          <a href="#features" className="hover:text-[var(--primary)] transition-colors">
            Features
          </a>
          <a href="#how-it-works" className="hover:text-[var(--primary)] transition-colors">
            How it Works
          </a>
          <a href="#contact" className="hover:text-[var(--primary)] transition-colors">
            Contact
          </a>
        </div>

        <div className="flex items-center gap-4">
          <ThemeToggle />

          <motion.button
            className="hidden md:block px-6 py-2 rounded-full border-2 border-black dark:border-white hover:bg-black hover:text-white dark:hover:bg-white dark:hover:text-black transition-all"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Login
          </motion.button>

          <motion.button
            className="px-6 py-2 rounded-full border-2 border-black dark:border-white shadow-[4px_4px_0px_0px_rgba(139,92,246,1)]"
            style={{ background: 'var(--primary)', color: 'white' }}
            whileHover={{ scale: 1.05, rotate: -2 }}
            whileTap={{ scale: 0.95 }}
          >
            Sign Up
          </motion.button>
        </div>
      </div>
    </nav>
  );
}
