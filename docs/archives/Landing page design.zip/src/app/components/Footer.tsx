import { motion } from 'motion/react';
import { Github, Twitter, Linkedin, Mail } from 'lucide-react';

const footerLinks = {
  Product: ['Features', 'Pricing', 'How it Works', 'FAQ'],
  Company: ['About', 'Blog', 'Careers', 'Press'],
  Resources: ['Documentation', 'Help Center', 'Community', 'Contact'],
  Legal: ['Privacy', 'Terms', 'Security', 'Cookies'],
};

const socialLinks = [
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Github, href: '#', label: 'GitHub' },
  { icon: Linkedin, href: '#', label: 'LinkedIn' },
  { icon: Mail, href: '#', label: 'Email' },
];

export function Footer() {
  return (
    <footer id="contact" className="border-t-2 border-black dark:border-white bg-white dark:bg-[#262626] py-16 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-5 gap-12 mb-12">
          <div className="md:col-span-1">
            <motion.div
              className="text-2xl font-bold mb-4"
              style={{ fontFamily: 'var(--font-heading)' }}
              whileHover={{ scale: 1.05 }}
            >
              FixMyBits
            </motion.div>
            <p className="text-sm opacity-60 mb-6">
              Connecting testers and startups to build better products.
            </p>
            <div className="flex gap-3">
              {socialLinks.map((social) => {
                const Icon = social.icon;
                return (
                  <motion.a
                    key={social.label}
                    href={social.href}
                    aria-label={social.label}
                    className="w-10 h-10 rounded-full border-2 border-black dark:border-white flex items-center justify-center hover:bg-[var(--primary)] hover:border-[var(--primary)] transition-colors"
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <Icon className="w-5 h-5" />
                  </motion.a>
                );
              })}
            </div>
          </div>

          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h3 className="font-bold mb-4" style={{ fontFamily: 'var(--font-heading)' }}>
                {category}
              </h3>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="text-sm opacity-60 hover:opacity-100 hover:text-[var(--primary)] transition-all"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="pt-8 border-t-2 border-black dark:border-white text-center text-sm opacity-60">
          <p>&copy; {new Date().getFullYear()} FixMyBits. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
