import { useEffect, useRef } from 'react';

export function ScrollSound() {
  const lastScrollY = useRef(0);
  const audioContextRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    const initAudioContext = () => {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
    };

    const playTick = () => {
      if (!audioContextRef.current) {
        initAudioContext();
      }

      const audioContext = audioContextRef.current!;
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      oscillator.frequency.value = 600;
      oscillator.type = 'sine';

      gainNode.gain.setValueAtTime(0.05, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.15);

      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.15);
    };

    const handleWheel = (e: WheelEvent) => {
      const currentScrollY = window.scrollY;

      if (e.deltaY > 0 && currentScrollY > lastScrollY.current) {
        playTick();
      }

      lastScrollY.current = currentScrollY;
    };

    document.addEventListener('click', initAudioContext, { once: true });

    window.addEventListener('wheel', handleWheel, { passive: true });

    return () => {
      window.removeEventListener('wheel', handleWheel);
    };
  }, []);

  return null;
}
