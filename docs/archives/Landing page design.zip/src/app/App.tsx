import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { TrustBar } from './components/TrustBar';
import { Features } from './components/Features';
import { HowItWorks } from './components/HowItWorks';
import { Careers } from './components/Careers';
import { CTA } from './components/CTA';
import { Footer } from './components/Footer';
import { ScrollSound } from './components/ScrollSound';
import { AnimatedBackground } from './components/AnimatedBackground';

export default function App() {
  return (
    <div className="min-h-screen relative">
      <AnimatedBackground />
      <ScrollSound />
      <div className="relative z-10">
        <Navbar />
        <Hero />
        <TrustBar />
        <Features />
        <HowItWorks />
        <Careers />
        <CTA />
        <Footer />
      </div>
    </div>
  );
}